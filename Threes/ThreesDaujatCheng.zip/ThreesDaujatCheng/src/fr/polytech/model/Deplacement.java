package fr.polytech.model;

public enum Deplacement {
	  GAUCHE,
	  DROIT,
	  HAUT,
	  BAS;	
	}
